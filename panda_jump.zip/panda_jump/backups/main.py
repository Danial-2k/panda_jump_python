# Doodle Jump programmieren

import pygame

pygame.init()

# library of game constants
white = (255, 255, 255)
black = (0, 0, 0)
gray = (128, 128, 128)
WIDTH = 400
HEIGHT = 500
background = white
player = pygame.image.load('panda.png')
fps = 60
font = pygame.font.Font('Cute_Aurora.ttf', 16)
timer = pygame.time.Clock()

# Create Screen
screen = pygame.display.set_mode([WIDTH, HEIGHT])
pygame.display.set_caption('Panda Jump')

running = True
while running == True:
    timer.tick(fps)
    screen.fill(background)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.flip()
pygame.quit()
